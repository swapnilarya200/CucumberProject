//Question15 : E-commerce Product Purchase
package stepDefinitions;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	WebDriver driver;
	 @Given("I am logged into the application")
	public void i_am_logged_into_the_application() throws InterruptedException {
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com");
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		Thread.sleep(2000);
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);
	
	}
	@When("I search for a product {string}")
	public void i_search_for_a_product(String ProductName) {
	    ProductName = "Sauce Labs Backpack";
	    driver.getPageSource().contains(ProductName);
	}
	@Then("I should see the product details")
	public void i_should_see_the_product_details() {
		WebElement productTitle = driver.findElement(By.className("inventory_container"));
		assert productTitle.isDisplayed();
		
	}
	@When("I add the product  to the cart")
    public void i_add_the_product_to_cart() {
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
	}
	@Then("I should see the product in the cart")
	public void i_should_see_the_product_in_the_cart() {
		driver.findElement(By.className("shopping_cart_link")).click();
		 WebElement cartItem = driver.findElement(By.className("cart_list"));
		 assert cartItem.isDisplayed();
	}
	@When("I proceed to checkout")
	public void i_proceed_to_checkout() {
	    driver.findElement(By.id("checkout")).click();
	}
	@When("I enter the checkout details")
	public void i_enter_the_checkout_details() throws InterruptedException {
		 driver.findElement(By.id("first-name")).sendKeys("Swapnil");
		    Thread.sleep(1000);
		    driver.findElement(By.id("last-name")).sendKeys("Arya");
		    Thread.sleep(1000);
		    driver.findElement(By.id("postal-code")).sendKeys("12345");
		    Thread.sleep(2000);
		    
		    
	}
	@And("I confirm the order")
    public void i_confirm_the_order() throws InterruptedException {
		driver.findElement(By.id("continue")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("finish")).click();
	}
	 @Then("I should see the purchase confirmation message")
	 public void i_should_see_the_purchase_confirmation_message() {
		 WebElement confirmationMessage = driver.findElement(By.className("checkout_complete_container"));
		 assert confirmationMessage.getText().contains("Thank you for your order!");
		 driver.close();
		 
	 }
}
